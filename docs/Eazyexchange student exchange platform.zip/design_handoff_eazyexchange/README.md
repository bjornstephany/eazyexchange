# Handoff: Eazyexchange — Complete Product Design

## Overview
This bundle contains the full design for Eazyexchange, a platform for organizing school student exchanges. It covers:

1. **Marketing** — landing page, pricing reference, logo/brand.
2. **Organizer app** — dashboard (overview / exchanges / applications), forms, documents, students, settings.
3. **Student app** — « Mon dossier » student space.
4. **Auth & public pages** — login, signup, accept-invite, public application form, invite response, billing (`Eazyexchange Pages Round 2.dc.html`, screens 1a–1g).
5. **System states** — loading, error, expired/invalid link, Stripe billing return, empty states (`Eazyexchange System States.dc.html`, screens 2a–2f).

Target codebase: the `eazyexchange` Next.js (App Router) + Supabase + Tailwind/shadcn repo. Each screen below is mapped to its existing route/component.

**Implementation order suggestion:** design system tokens → organizer shell → dashboard views → forms/docs/students/settings → student space → auth/public pages → system states → landing.

## About the Design Files
The HTML files in this bundle are **design references created in HTML** — they show intended look and behavior, not production code. Recreate them in the Next.js codebase using its existing patterns (shadcn `Button`/`Input`/`Card`, server components, Tailwind). Do not copy the HTML directly. Open the `.dc.html` files in a browser (keep `support.js` next to them) to inspect exact rendering; all styles are inline on each element.

## Fidelity
**High-fidelity.** Colors, type, spacing, radii, and copy are final. Frames are drawn at 1280×800 desktop scale (displayed scaled ~52% — read pixel values from the inline styles, which are in true 1280-scale px). Recreate pixel-perfectly, adapting to responsive widths with the layout notes below.

## Important architectural decision
The organizer app follows the **designed shell** (dark 82px icon rail + session top bar — see `Eazyexchange Dashboard.dc.html` in the design project), *not* the codebase's current page-per-route organization:

- **New exchange** (`app/(organizer)/exchanges/new` + `NewExchangeForm.tsx`) becomes a **modal** opened from the session selector in the top bar (screen 1g) — not a standalone page.
- **Applications review** (`app/(organizer)/exchanges/[id]/applications`) is **replaced** by the Dashboard's « Candid. » view; no separate page.

## Design Tokens
Colors:
- Canvas / app background: `#EEF1F7` (page canvas around cards `#E9EDF4` in design docs — use `#EEF1F7` in product)
- Ink (primary text / navy): `#10203F` · Rail navy: `#0E1B38`
- Primary blue: `#2456E6` · hover `#1D48C7` · light accent `#3B6EF6`
- Secondary text: `#5B6B8C` · tertiary/mono microcopy: `#8A97B2` · disabled/ghost: `#9AA6C0`
- Borders: cards `#E4E9F2` · inputs `#C4CDE0` · frames/dashed `#C4CDE0`/`#D6DCEA`
- Fills: subtle `#F1F4F9` · hover row `#F7F9FE`/`#FAFBFE` · input hint bg `#F5F7FC`
- Blue tint: bg `#E6ECFD`, border `#C8D6FA`, text `#1D48C7`
- Success: bg `#DCF3E6`, text `#0F7A3D` · Warning: bg `#FCF0DB`, text `#9A6B15` · Danger: bg `#FBE7E4`, text `#C0392B`
- Skeleton shimmer: `linear-gradient(90deg,#E3E8F1 25%,#F1F4FA 50%,#E3E8F1 75%)`, `background-size:200% 100%`, animate background-position 200%→−200% over 1.4s linear infinite
- Progress track: `#DDE3EF`

Typography (Google Fonts):
- Headings: **Schibsted Grotesk** 700, letter-spacing −0.02em (page H1 30px, card H3 22–26px, item titles 16–17px)
- Body/UI: **IBM Plex Sans** 400–600 (body 15–16px, labels 600 13–14px, buttons 600 15–17px)
- Microcopy/labels/status: **IBM Plex Mono** 500–600, 11–14px, uppercase micro-labels with letter-spacing .08–.14em

Radii: cards 18px · inner cards/list containers 14–16px · inputs 10–11px · buttons 9–11px · pills 999px.
Shadows: floating card `0 18px 40px -30px rgba(16,32,63,.25)` · modal `0 40px 80px -40px rgba(6,12,28,.6)`.
Buttons: primary = blue bg / white text, 14–15px vertical padding; secondary = white bg + `#C4CDE0` border; ghost = borderless `#5B6B8C` text.
Inputs: 44–50px tall, white bg, 1px `#C4CDE0` border; focused field: 2px `#2456E6` border. Placeholder color `#9AA6C0`.

Logo: two overlapping circles — navy `#10203F` (top-left) + blue `#2456E6` (bottom-right, `mix-blend-mode:multiply`), wordmark "Eazyexchange" Schibsted Grotesk 700. On dark rail: white + `#3B6EF6` circles, no wordmark.

Language: all product copy is **French** — vouvoiement for organizers, tutoiement for students. Exact copy strings are in the HTML files; use them verbatim.

---

## Screens — Marketing

### Landing page — `Eazyexchange.dc.html` → `app/page.tsx`
Public marketing page, **bilingual FR/EN** (all copy lives in a `t` dictionary in the file's logic; a FR/EN segmented toggle in the nav switches language — persist choice). White background (unlike the app's `#EEF1F7`). Sticky nav: 70px, `rgba(255,255,255,.86)` + `backdrop-filter:blur(12px)`, bottom border `#EEF1F7`; logo + wordmark left; links, FR/EN toggle (`#F1F4F9` pill), login and CTA right. Content column max-width 1180px, 40px side padding. Full section structure, copy, and an accent-color prop are in the file — treat the rendered default as final.

### Pricing — `Eazyexchange Pricing.dc.html`
Reference for the in-app payment/pricing section — bilingual, **yearly plans**; first exchange free, paid plans beyond. Plan tiles and copy here are the source of truth for plan *presentation*; the in-app billing page (screen 1f below) is the transactional version. Note plan caps: Starter 2 échanges, Growth 6, Scale unlimited.

### Logo — `Eazyexchange Logo.dc.html`
Brand mark construction: two overlapping circles (navy `#10203F` + blue `#2456E6`, blue multiplies over navy), with clear-space, dark-background, and favicon variants (favicon: navy rounded square, white + blue circles). Use for all logo usages, including the SVG favicon.

---

## Screens — Organizer app

All organizer pages share the **app shell**: 82px dark rail `#0E1B38` (logo mark on top; vertical nav items 62px wide, radius 11, icon + 9px IBM Plex Mono label, inactive `#8595B8`, active white on `rgba(255,255,255,.1)`; items: Aperçu, Échanges, Candid., Formul., Docs, Élèves, Réglages; MB avatar pinned bottom) + 66px white top bar (session selector « {Session} ▾ » 16px Schibsted + phase pill; right: 220px search field + primary « + Inviter des élèves »). Content scrolls in `padding:26px 28px 40px`; page H1 25–26px Schibsted + 13–14px `#5B6B8C` subline. The exact rail/topbar markup is in `Eazyexchange Dashboard.dc.html`.

Several organizer files expose design-variant props (layout A/B, etc.) — **implement the default state as rendered on load**; variants were exploration aids.

### Dashboard — `Eazyexchange Dashboard.dc.html` → organizer home
Three views switched by the rail (Aperçu / Échanges / Candid.), implemented in this one file:
- **Aperçu (Vue d'ensemble)**: applications funnel card (clickable stage tiles — 22px count + 11.5px label — that filter the table below; active filter shows a dismissible « Filtre : {stage} ✕ » pill), students table (grid columns, mono uppercase 10px headers on `#FBFCFE`, 14px rows with status pills, chevron, hover `#FAFBFE`), and a 344px right rail of secondary cards.
- **Échanges** and **Candid.** views: see the file (switch views via the rail in the browser). Candid. is the applications review — this REPLACES the codebase's `exchanges/[id]/applications` page.
- Print styles included (`data-noprint` hides chrome; content flows).

### Formulaires — `Eazyexchange Formulaires.dc.html` → forms management
H1 « Formulaires » — the forms/documents families complete to validate a dossier; standard templates plus custom ones. Card list layout per file.

### Docs — `Eazyexchange Docs.dc.html` → supporting documents
H1 « Documents » — pièces justificatives families upload; standard list or custom requests. Same shell + card vocabulary.

### Élèves — `Eazyexchange Eleves.dc.html` → students directory
H1 « Élèves »: master-detail — 340px left list column (search/filter + student rows) and detail panel for the selected student (dossier progress, forms, docs, contact).

### Réglages — `Eazyexchange Reglages.dc.html` → settings
H1 « Réglages » — « Votre compte, votre équipe et votre abonnement. » Max-width 1120px sections: account, team, subscription (subscription section links to billing/portal — consistent with screen 1f).

---

## Screens — Student app

### Espace élève — `Eazyexchange Espace Eleve.dc.html` → `app/(student)/my-forms`
Student home « Mon dossier »: minimal top bar (logo left; session label mono + avatar right), content column with mono kicker `MON DOSSIER`, H1 30px « Bonjour {prénom}, » + subline, dossier progress, and the checklist of pending forms/documents (cards with status, due date, primary action). Empty/all-done state is screen 2f. Tutoiement throughout.

---

## Screens — System States (`Eazyexchange System States.dc.html`)

### 2a · Loading — `app/(organizer)/loading.tsx` & `app/(student)/loading.tsx` (replaces `LoadingState.tsx` pulse skeleton)
Full-viewport centered column (gap 30px) on `#EEF1F7`:
1. Animated brand mark 80×60: the two logo circles (48px) swap positions — each translates ±(15px, 7px at design scale ~32px,15px at this size — see keyframes `exL`/`exR`: 50% keyframe `translate(±15px,±7px)` scaled to mark size) over **1.6s `cubic-bezier(.45,0,.25,1)` infinite**.
2. Wordmark 28px.
3. Indeterminate bar: 220×5px track `#DDE3EF`, 80px blue segment sliding left→right, **1.1s `cubic-bezier(.4,.1,.6,.9)` infinite** (keyframe: translateX(−64px)→translateX(168px) proportional to track).
4. Mono caption 14px `#8A97B2`: `CHARGEMENT DE VOTRE ESPACE…`

### 2b · Error — `error.tsx` (organizer + student), `components/ErrorState.tsx`
Centered column: broken-link motif (navy circle 48px — 96px dashed line 3px `#AEB7CB` — blue circle 48px), H3 36px « Le fil s'est rompu. », body 18px `#5B6B8C` max-width 520px centered (« …vos données sont en sécurité… »), buttons: primary « Réessayer » (calls `reset()`) + secondary « Tableau de bord ». Map Supabase/auth errors through the existing `friendlyMessage()`.

### 2c · Expired / invalid link — `apply/resume/[token]`, `invite/[token]` invalid & expired branches
Centered column: **greyed-out logo** (circles `#9AA6C0` + `#C4CDE0` multiply, 55% opacity, 64×48), H3 32px « Ce lien n'est plus valide », body 17px (tutoiement, reassures links expire to protect the dossier), secondary button « Contacter l'organisateur » (mailto organizer). Same template serves invalid, expired, already-answered, already-submitted (adjust heading/body per case).

### 2d · Billing return — `app/billing/return` + `ReturnPoller.tsx`
Centered: logo+wordmark 24px; white card 560px (radius 18, padding 34×40) with 3 step rows (gap 26):
1. ✓ green disc 36px `#0F7A3D` — « Paiement reçu » (500)
2. Spinner 36px: 3.5px ring `#C8D6FA`, top arc `#2456E6`, 0.9s linear infinite — « Activation de votre abonnement… » (600)
3. Empty 36px circle 2px `#C4CDE0`, row at 55% opacity — « Redirection vers le tableau de bord »
Below card, mono 14px `#8A97B2`: « Vous serez redirigé automatiquement — ne fermez pas cette page. » Steps advance as the poller confirms; on success step 3 turns active then redirects.

### 2e · Organizer empty state — dashboard with zero exchanges
App shell + H3 30px « Tableau de bord », then a **2px dashed `#C4CDE0`** zone (radius 22, padding 64×40, bg `rgba(255,255,255,.5)`) centered column: logo 64×48, title 24px « Aucun échange pour l'instant », body 17px max 480px, primary button « + Nouvel échange » (opens the 1g modal).

### 2f · Student empty state — my-forms, nothing pending
Student shell (session label + avatar top-right). Content column (max 900px): mono kicker `MON DOSSIER`, H3 30px « Bonjour {prénom}, », then blue-tint banner (bg `#E6ECFD`, border `#C8D6FA`, radius 22, padding 30×34): 66px blue `#1D48C7` rounded-18 square with white ✓, title 22px « Tout est à jour », body 16px (tutoiement). Below: full progress bar (10px, track `#DDE3EF`, fill blue) + mono « 6 / 6 envoyés » (real counts).

---

## Screens — Remaining Pages (`Eazyexchange Pages Round 2.dc.html`)

Auth/billing/invite pages share a **centered-card layout**: `#EEF1F7` viewport, logo+wordmark 23px above, white card radius 18 border `#E4E9F2` + floating shadow, padding ~36×42.

### 1a · Login — `app/(auth)/login`
Card 460px: H3 24px « Connexion » → Google button (white, `#C4CDE0` border, 24px `#F1F4F9` square with blue "G" glyph — replace with the real Google logo asset, label « Continuer avec Google ») → mono divider « ou » → E-mail + Mot de passe fields (50px) → primary full-width « Se connecter ». URL-flag errors (`invite_invalid`, `oauth_failed`, `not_invited`, `signup_failed`) render as 14px `#C0392B` text above the button.

### 1b · Signup — `app/(auth)/signup`
Two-column centered (gap 60): **left brand panel** 340px — logo, H3 30px « Organisez vos échanges scolaires sans tableur. », body 16px, mono `ESSAI GRATUIT · 1 ÉCHANGE`; **right card** 460px — H3 22px « Créer votre compte », Google « S'inscrire avec Google », divider, 2-col grid: Nom complet / Établissement, then E-mail, Mot de passe (placeholder « 8 caractères minimum », `minLength=8`), primary « Créer mon compte ». Submitted state: reuse card with « Vérifiez votre e-mail » (see codebase copy). Stack columns under ~900px.

### 1c · Accept invite (student) — `app/(auth)/accept-invite`
Card 460px: blue-tint pill with exchange name (e.g. « Espagne · Automne 2026 ») → H3 24px « Configure ton compte » + sub « Dernière étape avant ton espace élève. » → Google « Continuer avec Google » → divider « ou choisis un mot de passe » → Nom complet, Mot de passe (46px) → primary « C'est parti » → `/my-forms`.

### 1d · Public application form — `app/apply/[slug]` + `ApplicationForm.tsx`
Column max-width 720px, top padding 52px. Header row: logo+wordmark 17px left; right: mono autosave indicator (`ENREGISTRÉ ✓` / `ENREGISTREMENT…` — wire to the existing 800ms-debounced autosave) + EN/FR segmented toggle (active segment navy bg white text). Then blue pill « Candidature », H3 30px exchange name, intro (mentions autosave + finish later). Form card (radius 18, only top corners rounded as it flows into the next section): section header row — mono blue `1/4` + 19px title (sections: élève, famille, santé, motivation per `APPLICATION_SECTIONS`) — 2-col field grid (gap 16), required fields marked `*`, focused field 2px blue border. **Sticky bottom bar** (not drawn in frame): white, top border, containing ghost « Terminer plus tard » (flush + email resume link, existing `onFinishLater`) and primary « Envoyer ma candidature ». Closed/invalid slug states use the 2c template.

### 1e · Invite response — `app/invite/[token]` + `InviteResponseForm.tsx`
Centered card 520px: success pill « Candidature acceptée 🎉 » (green tint) → H3 26px « {Prénom}, tu es invitée à l'échange {nom} ! » → body « Ta candidature a été retenue. Veux-tu participer ? » → primary full-width « Oui, je veux participer » + secondary « Non merci » (gap 10) → divider → optional note textarea (placeholder « Si tu hésites, laisse une note (facultatif) ») + underlined ghost « Peut-être — j'ai besoin de temps ». Post-response confirmations reuse the card with the existing copy.

### 1f · Billing — `app/billing`
Centered card 640px: H3 24px « Offres & facturation » + trial line « Vous êtes en essai gratuit (1 échange)… ». 3-col plan grid (gap 14): tiles radius 14, padding 20×18 — name 17px Schibsted + cap 13.5px `#5B6B8C`. **Starter — 2 échanges**, **Growth — 6 échanges** (pre-selected: 2px blue border, bg `#F7F9FE`, floating `POPULAIRE` mono pill on blue), **Scale — Échanges illimités**. Footer row: primary flex-1 « Continuer avec {plan} » (→ `/billing/checkout?plan=`) + ghost « Retour au tableau de bord ». Active-subscription state: replace plan grid with current-plan sentence + « Gérer la facturation » (Stripe portal); grace-period warning in `#C0392B`.

### 1g · New exchange — modal in the organizer shell (replaces `exchanges/new` page)
Backdrop: full organizer shell (dark rail 82px `#0E1B38` with Aperçu/Échanges/Candid./Formul./Docs/Élèves/Réglages items + MB avatar; top bar 66px with session selector « {Session} ▾ », status pill, search, « + Inviter des élèves ») under scrim `rgba(14,27,56,.45)`.
Modal 560px, radius 18, padding 34×38, shadow `0 40px 80px -40px rgba(6,12,28,.6)`: H3 24px « Nouvel échange » + sub « Un échange relie votre établissement à un partenaire, pour une session donnée. » → Nom de l'échange (placeholder « France–Canada 2026 ») → grid 150px/1fr: Année (default current year) + Établissement partenaire (placeholder « Lycée Victor Hugo ») → right-aligned ghost « Annuler » + primary « Créer l'échange ». Include the conditional « Votre établissement » field when `needsSchoolName`. Opens from the session selector dropdown and from empty state 2e.

## Interactions & Behavior
- Buttons: hover darkens primary to `#1D48C7`; white buttons hover `#F5F7FC`; rows hover `#F7F9FE`. Busy states swap labels (« Connexion… », « Création… ») and disable.
- Animations: only 2a/2d use motion (durations/easings above). No entrance animations elsewhere.
- All error strings surface as 14px `#C0392B` text inside the relevant card.
- Status pill palette (candidatures & elsewhere): Acceptée = success, Envoyée = blue tint, Peut-être = warning, Refusée = danger, Brouillon = `#F1F4F9`/`#5B6B8C`.

## State Management
Reuse existing state: Supabase auth calls (1a–1c), `ApplicationForm` autosave/draft/submit + resume-link (1d), `respondToInvitation` (1e), plan checkout/portal routes (1f), `createExchange` (1g), `ReturnPoller` (2d — extend to expose which step is active). No new data requirements.

## Assets
No image assets. Logo is pure CSS (two circles, values above). Google button currently uses a placeholder "G" — substitute the official Google identity asset. Fonts via Google Fonts: Schibsted Grotesk, IBM Plex Sans, IBM Plex Mono.

## Files
- `Eazyexchange Design System.dc.html` — tokens, type, logo, components extracted from the product (start here)
- `Eazyexchange Logo.dc.html` — brand mark construction + favicon
- `Eazyexchange.dc.html` — marketing landing page (bilingual)
- `Eazyexchange Pricing.dc.html` — pricing/plans reference
- `Eazyexchange Dashboard.dc.html` — organizer shell + Aperçu / Échanges / Candid. views
- `Eazyexchange Formulaires.dc.html` — forms management
- `Eazyexchange Docs.dc.html` — documents management
- `Eazyexchange Eleves.dc.html` — students directory (master-detail)
- `Eazyexchange Reglages.dc.html` — settings
- `Eazyexchange Espace Eleve.dc.html` — student space « Mon dossier »
- `Eazyexchange System States.dc.html` — screens 2a–2f
- `Eazyexchange Pages Round 2.dc.html` — auth/public/billing screens 1a–1g
- `support.js` — runtime needed to open the files in a browser (keep alongside them)
